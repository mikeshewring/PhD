README - CLC90
------------------------------------

Version 18_5:

New data included. Changes consist of:

1. New parts were included to clc90 - Guernsey and Jersey islands. For actual coverage see CLC_coverage_v18_5.pdf



Note (list of known errors): Some redundant lines between neighbouring
polygons with the same code are still present in database, but only as result 
of persisting �adaptive tilling� procedure limitation of ArcGIS.
Polygons under MMU 25 Ha can be present along national borders and along 'adaptive tilling' tiles boundaries. Polygons (slivers) under 0.1 Ha can be present only along 'adaptive tilling' tiles boundaries.

Prepared by
GISAT 02/2016
For more information contact tomas.soukup@gisat.cz